#include "LED.h"
#include "UART.h"
#include <string.h>

int redflash = 0;
int greenflash = 0;
char rxByte;
char buffer[16];
int loopcounter = 0;
int counter = 0;

void parsecommand(char* cmd){
	if(strncmp(cmd, "RON", strlen(cmd))){
		Red_LED_On();
		redflash = 0;
	}
	else if(strncmp(cmd, "ROFF", strlen(cmd))){
		Red_LED_Off();
		redflash = 0;
	}
	else if(strncmp(cmd, "GON", strlen(cmd))){
		Green_LED_On();
		greenflash = 0;
	}
	else if(strncmp(cmd, "GOFF", strlen(cmd))){
		Green_LED_Off();
		greenflash = 0;
	}
	else if(strncmp(cmd, "RFLASH", strlen(cmd))){
		redflash = 1;
	}
	else if(strncmp(cmd, "GFLASH", strlen(cmd))){
		greenflash = 1;
	}
	else if(strncmp(cmd, "FLASHOFF", strlen(cmd))){
		greenflash = 0;
		redflash = 0;
	}
}
void readcommand(){
	rxByte = USART_Read(USART2); //Read byte
		if (rxByte != 0){
			if(rxByte == 015){ //If enter, check the command
				buffer[counter] = '\0';
				parsecommand(buffer);
				USART_Write(USART2, (uint8_t *)buffer, counter);
				USART_Write(USART2, (uint8_t *)"\r\n", counter);
				memset(buffer, 0, sizeof(buffer));
				counter = 0;
			}
			else if (rxByte == 010){ //If backspace, remove the last character
				if (buffer[0] == ' ')
					return;
				buffer[counter] = ' ';
				counter--;
				USART_Write(USART2, (uint8_t *)buffer, counter);
			}
			else{
				buffer[counter] = rxByte;
				USART_Write(USART2, (uint8_t *)buffer, counter);
				counter++;
			}
		}
}

//green is false, red is true
void flash(){
	if (redflash == 1 || greenflash == 1){
			USART_Delay(1000);
			loopcounter++;
			if(loopcounter > 1000){
				loopcounter = 0;
				if(redflash == 0)
					Red_LED_Toggle();
				if(greenflash == 0)
					Green_LED_Toggle();
			}
		}
}

void commandloop(){
	while (1){
		readcommand();
		flash();
	}
}
