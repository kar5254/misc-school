#include "LED.h"
#include "UART.h"
void readcommand();
void commandloop();
void flash();